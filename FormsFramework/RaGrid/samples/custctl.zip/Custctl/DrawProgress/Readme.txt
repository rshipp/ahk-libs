
DRAWPROGRESS CUSTOM CONTROL

by Faiseur


This custom control add a special ProgressBar.

The base work (ProgressBar style) is from the author "hinte". I did not succeed in finding the author, but this source was free on the Net.


I have added:

- Show (or not) text option 

- Routine percent (DrawProgress calculates automatically the position in percent according to the maximum value)

- Routine position

- Color model: blue, red, green and light blue

- Color and bitmap background option

- 7 examples with source

- Converted in custom control for RadAsm, in DLL and static version :-)



Thanks to KetilO for his support and help in private data routine.

Important note: In this version you need RadAsm to configure 'Modelcolor' and 'Modeltext'.




16.6.2005


email: clarte@gmail.com





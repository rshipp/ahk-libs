
RAGRAPH CUSTOM CONTROL

by Faiseur


DLL and static version with examples, tested with windows 2000 and Windows XP.


A GREAT thanks to KetilO to have improved management of the memory of RaGraph.



26.6.2005


email: clarte@gmail.com





// Gradient Fill Progress Bar
// By Tola/AmoK [mailto: tola@gmx.it]
// MASM/RadASM Project conversion by bitRAKE
// RadASM Custom Control by KetilO

Tola:
This is a simple owner drawn control I wrote cause the
standard progress bar is so damn ugly ;)
Simply include the file progress.asm and register the
control (preferably before trying to use it ;)
It's written for TASM but should be easy to convert.
Controlling the progress bar is similar to the standard
one (see messages below), I didn't implement a minimum
range, though (mostly because that feature was useless
to me).
Feel free to use the control in your programs, modify
and improve it. [I just might add that I love seeing my
name in readme files ;)]


Messages:

UPM_SETBARCOLORS wParam=COLORREF, lParam=COLORREF
UPM_SETBARCOLOR1 wParam=COLORREF, lParam=unused
UPM_SETBARCOLOR2 wParam=COLORREF, lParam=unused
UPM_SETRANGE     wParam=max. range, lParam=unused
UPM_SETPOS       wParam=position, lParam=unused
UPM_SETSTEP      wParam=step, lParam=unused

UPM_GETBARCOLOR1 wParam & lParam=unused, returns COLORREF
UPM_GETBARCOLOR2 wParam & lParam=unused, returns COLORREF
UPM_GETRANGE     wParam & lParam=unused, returns max. range
UPM_GETPOS       wParam & lParam=unused, returns posisiton
UPN_GETSTEP      wParam & lParam=unused, returns step

UPM_STEPIT       wParam & lParam=unused
UPM_RANDOMCOLOR  wParam & lParam=unused

KetilO:
In RadASM.ini section [CustCtrl], x=CustCtrl.dll,y
x is next free number.
y is number of controls in the dll.
In this case there is only one control.

x=GradProgress.dll,1

Copy GradProgress.dll to c:\windows\system
